package in.nareshit.raghu.service;

import java.util.List;

import in.nareshit.raghu.model.PurchaseDtl;
import in.nareshit.raghu.model.PurchaseOrder;

public interface IPurchaseOrderService {

	//screen#1
	public Integer savePurchaseOrder(PurchaseOrder po);
	public PurchaseOrder getOnePurchaseOrder(Integer id);
	public List<PurchaseOrder> getAllPurchaseOrders();
	
	//screen#2
	public Integer savePurchaseDtl(PurchaseDtl dtl);
}
